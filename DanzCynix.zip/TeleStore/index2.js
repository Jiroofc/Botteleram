const { Telegraf } = require('telegraf');
const fs = require('fs');
const path = require('path');
const config = require('./config.json');

const bot = new Telegraf(config.token);

bot.start((ctx) => {
    ctx.replyWithPhoto(
        config.thumbnailUrl,
        {
            caption: `Selamat datang, ${ctx.from.first_name}!
            
𝗛𝗮𝗹𝗹𝗼 𝗸𝗮𝗸, 𝗠𝗮𝗮𝗳 𝗝𝗶𝗸𝗮 𝗣𝗲𝗹𝗮𝘆𝗮𝗻𝗮𝗻 𝗕𝗼𝘁 𝗕𝗮𝗻𝘆𝗮𝗸 𝗞𝗲𝗸𝘂𝗿𝗮𝗻𝗴𝗮𝗻𝗻𝘆𝗮 𝗞𝗮𝗿𝗻𝗮 𝗕𝗼𝘁 𝗜𝗻𝗶 𝗠𝗮𝘀𝗶𝗵 𝗩𝗲𝗿𝘀𝗶 1.0.0 (𝗕𝗘𝗧𝗔)`,
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [
                        {text: 'YouTube', url: 'https://www.youtube.com'},
                        {text: 'WhatsApp', url: config.socialMedia.whatsapp}
                    ],
                    [
                        {text: 'OPEN MENU', callback_data: 'menu'}
                    ]
                ]
            }
        }
    );
});

bot.action('menu', (ctx) => {
    ctx.deleteMessage().catch(() => {});;
    ctx.replyWithPhoto(
        config.thumbnailUrl2,
        {
            caption: `
   ╾────𝙇𝙞𝙨𝙩 • 𝙈𝙚𝙣𝙪────╼
  ╾───────────────╼
  ➣ /allmenu
  ╾───────────────╼
  ➣ /topup
  ╾───────────────╼
  ➣ /owner
  ╾───────────────╼
  ➣ /produk
  ╾───────────────╼
  ➣ /donasi
  ╾───────────────╼

Bantu Bot Ini Terus Berkembang Dengan Cara Berdonasi 
`,
            reply_markup: {
                inline_keyboard: [
                    [
                        {text: 'PANEL 🏷️', callback_data: 'panel'},
                        {text: 'WEB 👨‍💻', callback_data: 'web'}],
                    [
                        {text: 'F IG🗂️', callback_data: 'fig'},
                        {text: 'F TIKTOK🗃️', callback_data: 'ftt'}],
                    [
                        {text: 'V TIKTOK🗃️', callback_data: 'vtt'},
                        {text: 'V IG🗂️', callback_data: 'vig'}],
                    [
                        {text: 'Clear Chat', callback_data: 'clear'}
                    ]
                ]
            }
        }
    );
});

bot.action('panel', (ctx) => {
    ctx.deleteMessage().catch(() => {});;
    ctx.replyWithPhoto(
        config.thumbnailUrl2,
        {
            caption: `
╾───────────────╼
  RAM YANG TERSEDIA
╾───────────────╼
`,
            reply_markup: {
                inline_keyboard: [
                    [
                        {text: '1GB 🏷️', callback_data: 'button4'},
                        {text: '2GB 🏷️', callback_data: 'web'}],
                    [
                        {text: '3GB 🏷️', callback_data: 'fig'},
                        {text: '4GB 🏷️', callback_data: 'ftt'}],
                    [
                        {text: '💎UNLIMITED💎', callback_data: 'vig'}],
                    [
                        {text: 'Clear Chat', callback_data: 'start'}
                    ]
                ]
            }
        }
    );
});


/*bot.action('button4', (ctx) => {
    ctx.answerCbQuery('Anda menekan Tombol 4');
});*/

bot.action('button5', (ctx) => {
    ctx.answerCbQuery('Anda menekan Tombol 5');
});

bot.action('web', (ctx) => {
    ctx.deleteMessage();
    const productPhotoPath = path.join(__dirname, 'cranz/tes2.jpg');
    if (fs.existsSync(productPhotoPath)) {
        ctx.replyWithPhoto(
            { source: fs.createReadStream(productPhotoPath) },
            {
                caption: 'Nama Produk: Produk A\nHarga: $10\nDeskripsi: Ini adalah deskripsi singkat tentang produk.',
                reply_markup: {
                    inline_keyboard: [
                        [
                            {text: 'Beli Sekarang', callback_data: 'buy'}
                        ]
                    ]
                }
            }
        ).then(() => ctx.deleteMessage());
    } else {
        ctx.reply('Maaf, foto produk tidak ditemukan.');
    }
});


bot.action('buy', (ctx) => {
    ctx.answerCbQuery('Anda telah memilih untuk membeli produk ini. Silakan lanjutkan ke proses pembayaran.');
});

bot.action('clear', (ctx) => {
    ctx.deleteMessage().catch(() => {});
    const productPhotoPath = path.join(__dirname, 'cranz/tp.jpg');
    const audioPath = path.join(__dirname, 'cranz/audio.mp3');
    if (fs.existsSync(productPhotoPath) && fs.existsSync(audioPath)) {
        ctx.replyWithPhoto(
            { source: fs.createReadStream(productPhotoPath) },
            {
                caption: 'Ini adalah teks yang Anda inginkan.',
                reply_markup: {
                    inline_keyboard: [
                        [
                            {text: 'Tombol Anda', callback_data: 'button'}
                        ]
                    ]
                }
            }
        ).then(() => {
            return ctx.replyWithAudio(
                { source: fs.createReadStream(audioPath) }
            );
        }).then(() => ctx.deleteMessage()).catch((err) => console.log(err));
    } else {
        ctx.reply('Maaf, foto atau audio tidak ditemukan.').catch((err) => console.log(err));
    }
});
/*Fungsi untuk memulai bot
function startBot() {
    bot.launch()
        .then(() => {
            console.log('Bot started successfully.');
        })
        .catch((err) => {
            console.error('Error starting bot:', err);
            console.log('Retrying in 10 seconds...');
            setTimeout(startBot, 10000);
        });
}
startBot();*/
bot.launch();
